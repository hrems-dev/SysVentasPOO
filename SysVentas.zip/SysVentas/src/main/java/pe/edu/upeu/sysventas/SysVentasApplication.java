package pe.edu.upeu.sysventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysVentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysVentasApplication.class, args);
	}

}
